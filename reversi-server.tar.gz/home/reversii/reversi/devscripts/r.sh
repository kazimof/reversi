#!/bin/bash
cat /root/reversi/ports.log | grep -i $1
